// ─────────────────────────────────────────────────────────────
// useHunterChallenges — React Query hooks for the personal
// Hunter's Challenge tracker.
//
// Supports both Armour Piece & Weapon challenges. Status evolves in-place:
//   crafting → upgrading → completed / abandoned
// ─────────────────────────────────────────────────────────────
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '../lib/supabase';
import { ADVENTURER_MAX_INSIGHT, adventurerInsightLabel } from '../data/schemas/adventurer';
import { WEAPON_FORGE_MATERIALS } from '../data/core/gear-materials';

// ── Types ────────────────────────────────────────────────────

export type ChallengeStatus = 'crafting' | 'upgrading' | 'completed' | 'abandoned';
export type ChallengeType   = 'armour_piece' | 'weapon' | 'visage_set' | 'adventurer' | 'buddy' | 'full_build' | 'monster';

export interface HunterChallenge {
  id:               string;
  user_id:          string;
  challenge_type:   ChallengeType;
  game:             string;

  // Armour-specific (denormalised for quick reads)
  armour_piece_id:  string | null;
  monster_id:       string | null;
  armour_slot:      string | null;
  set_variant:      string | null;
  set_name:         string | null;
  piece_image:      string | null;
  set_icon:         string | null;
  monster_name:     string | null;

  // Weapon-specific
  weapon_id:        string | null;
  weapon_type_id:   string | null;
  element_type:     string | null;
  special_skill:    string | null;

  // Visage-specific
  visage_id:        string | null;
  ink_type:         string | null;

  // Adventurer-specific
  adventurer_id:    string | null;

  // Buddy-specific
  buddy_id:         string | null;

  // Rarity progression (supports up to max 16 for gear, 4 for visages, 1 for recruits)
  craft_rarity:     number;
  current_rarity:   number;
  max_rarity:       number;

  // Status
  status:           ChallengeStatus;
  completed_at:     string | null;

  // Tracking details
  missing_material: string | null;
  missing_material_activity: string | null;

  // Meta
  sort_order:       number;
  notes:            string | null;
  created_at:       string;
  updated_at:       string;
}

export interface AddArmourChallengePayload {
  userId:          string;
  game:            string;
  armourPieceId:   string;
  monsterId:       string | null;
  armourSlot:      string;
  setVariant:      string;
  setName:         string | null;
  pieceImage:      string | null;
  setIcon:         string | null;
  monsterName:     string | null;
  craftRarity:     number;  // default 1
  maxRarity?:      number;  // default 16
}

export interface AddWeaponChallengePayload {
  userId:          string;
  game:            string;
  weaponId:        string;
  weaponName:      string;
  weaponTypeId:    string;
  monsterId:       string | null;
  monsterName:     string | null;
  elementType?:    string | null;
  specialSkill?:   string | null;
  pieceImage:      string | null;
  setIcon:         string | null;
  craftRarity?:    number;  // default 1
  maxRarity?:      number;  // default 16
}

export interface AddVisageChallengePayload {
  userId:          string;
  game?:           string;
  visageId:        string;
  visageName:      string;
  inkType:         string;
  monsterId?:      string | null;
  monsterName?:    string | null;
  pieceImage?:     string | null;
  setIcon?:        string | null;
  currentRarity?:  number;  // 0 = unowned, 1 = fine, 2 = rare, 3 = epic, 4 = superior
  craftRarity?:    number;  // default 1
  maxRarity?:      number;  // default 4
}

export interface AddAdventurerChallengePayload {
  userId:          string;
  game?:           string;
  adventurerId:    string;
  adventurerName:  string;
  pieceImage?:     string | null;
  role?:           string | null;
  element?:        string | null;
  notes?:          string | null;
  /** Current insight level of the adventurer: 0 = not recruited yet. */
  currentInsight?: number;
  /** Goal: 1 = just recruit, 2-7 = reach that insight level (7 = Max). */
  targetInsight?:  number;
}

export interface AddBuddyChallengePayload {
  userId:          string;
  game?:           string;
  buddyId:         string;
  buddyName:       string;
  pieceImage?:     string | null;
  tier?:           string | null;
  role?:           string | null;
  notes?:          string | null;
  /** Current tier level of the buddy: -1 = not collected/owned, 0 = Tier 0, 1 = Tier 1, 2 = Tier 2 (Max). */
  currentTierLevel?: number;
  /** Goal: 1 = just recruit (Tier 0+), 2 = Tier 1, 3 = Tier 2 (Max). */
  targetTierLevel?:  number;
}

export interface AddMonsterChallengePayload {
  userId:          string;
  game?:           string;
  monsterId:       string;
  monsterName:     string;
  pieceImage?:     string | null;
  setIcon?:        string | null;
  notes?:          string | null;
  completed?:      boolean;
}

export const VISAGE_RARITY_INDEX: Record<string, number> = {
  fine: 1,
  rare: 2,
  epic: 3,
  superior: 4,
};

export const VISAGE_RARITIES_BY_INDEX: Record<number, string> = {
  1: 'fine',
  2: 'rare',
  3: 'epic',
  4: 'superior',
};

export interface UpdateChallengeStatusPayload {
  challengeId:    string;
  status:         ChallengeStatus;
  currentRarity?: number;
  craftRarity?:   number;
  maxRarity?:     number;
  completedAt?:   string | null;
}

// ── Query Key ────────────────────────────────────────────────

export const HUNTER_CHALLENGES_KEY = 'hunter-challenges';

// ── useHunterChallenges ───────────────────────────────────────

export function useHunterChallenges(userId: string | null | undefined) {
  return useQuery({
    queryKey: [HUNTER_CHALLENGES_KEY, userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hunter_challenges')
        .select('*')
        .eq('user_id', userId!)
        .order('status', { ascending: true })       // crafting first
        .order('created_at', { ascending: true });

      if (error) throw error;
      return (data ?? []) as HunterChallenge[];
    },
    staleTime: 1000 * 60 * 2,
    refetchOnWindowFocus: false,
  });
}

// ── useAddArmourChallenge ─────────────────────────────────────

export function useAddArmourChallenge() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async (payload: AddArmourChallengePayload) => {
      // First check if an active challenge already exists for this piece
      const { data: existing } = await supabase
        .from('hunter_challenges')
        .select('id, status, created_at')
        .eq('user_id', payload.userId)
        .eq('armour_piece_id', payload.armourPieceId)
        .in('status', ['crafting', 'upgrading'])
        .maybeSingle();

      if (existing) {
        return { challenge: existing as unknown as HunterChallenge, wasAlreadyTracked: true };
      }

      const row = {
        user_id:         payload.userId,
        challenge_type:  'armour_piece' as const,
        game:            payload.game,
        armour_piece_id: payload.armourPieceId,
        monster_id:      payload.monsterId,
        armour_slot:     payload.armourSlot,
        set_variant:     payload.setVariant,
        set_name:        payload.setName,
        piece_image:     payload.pieceImage,
        set_icon:        payload.setIcon,
        monster_name:    payload.monsterName,
        craft_rarity:    payload.craftRarity ?? 1,
        current_rarity:  0,
        max_rarity:      payload.maxRarity ?? 16,
        status:          'crafting' as const,
      };

      const { data, error } = await supabase
        .from('hunter_challenges')
        .insert(row)
        .select()
        .single();

      if (error) throw error;
      return { challenge: data as HunterChallenge, wasAlreadyTracked: false };
    },

    onSuccess: (_data, variables) => {
      qc.invalidateQueries({ queryKey: [HUNTER_CHALLENGES_KEY, variables.userId] });
    },
  });
}

// ── useAddWeaponChallenge ─────────────────────────────────────

export function useAddWeaponChallenge() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async (payload: AddWeaponChallengePayload) => {
      // First check if an active challenge already exists for this weapon
      const { data: existing } = await supabase
        .from('hunter_challenges')
        .select('id, status, created_at')
        .eq('user_id', payload.userId)
        .eq('weapon_id', payload.weaponId)
        .in('status', ['crafting', 'upgrading'])
        .maybeSingle();

      if (existing) {
        return { challenge: existing as unknown as HunterChallenge, wasAlreadyTracked: true };
      }

      const row = {
        user_id:         payload.userId,
        challenge_type:  'weapon' as const,
        game:            payload.game,
        weapon_id:       payload.weaponId,
        weapon_type_id:  payload.weaponTypeId,
        monster_id:      payload.monsterId,
        set_name:        payload.weaponName,
        piece_image:     payload.pieceImage,
        set_icon:        payload.setIcon,
        monster_name:    payload.monsterName,
        element_type:    payload.elementType ?? null,
        special_skill:   payload.specialSkill ?? null,
        craft_rarity:    payload.craftRarity ?? 1,
        current_rarity:  0,
        max_rarity:      payload.maxRarity ?? 16,
        status:          'crafting' as const,
      };

      const { data, error } = await supabase
        .from('hunter_challenges')
        .insert(row)
        .select()
        .single();

      if (error) throw error;
      return { challenge: data as HunterChallenge, wasAlreadyTracked: false };
    },

    onSuccess: (_data, variables) => {
      qc.invalidateQueries({ queryKey: [HUNTER_CHALLENGES_KEY, variables.userId] });
    },
  });
}

// ── useAddVisageChallenge ─────────────────────────────────────

export function useAddVisageChallenge() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async (payload: AddVisageChallengePayload) => {
      const normInk = (payload.inkType || 'flames').toLowerCase();
      // Check if an active challenge already exists for this visage & ink
      const { data: existing } = await supabase
        .from('hunter_challenges')
        .select('id, status, created_at')
        .eq('user_id', payload.userId)
        .eq('visage_id', payload.visageId)
        .eq('ink_type', normInk)
        .in('status', ['crafting', 'upgrading'])
        .maybeSingle();

      if (existing) {
        return { challenge: existing as unknown as HunterChallenge, wasAlreadyTracked: true };
      }

      const curRarity = payload.currentRarity ?? 0;
      const maxR = payload.maxRarity ?? 4;
      const isComplete = curRarity >= maxR;
      const status: ChallengeStatus = isComplete ? 'completed' : curRarity > 0 ? 'upgrading' : 'crafting';

      const row = {
        user_id:         payload.userId,
        challenge_type:  'visage_set' as const,
        game:            payload.game || 'mho',
        visage_id:       payload.visageId,
        ink_type:        normInk,
        monster_id:      payload.monsterId || null,
        set_name:        payload.visageName,
        piece_image:     payload.pieceImage,
        set_icon:        payload.setIcon || payload.pieceImage,
        monster_name:    payload.monsterName || payload.visageName,
        craft_rarity:    payload.craftRarity ?? 1,
        current_rarity:  curRarity,
        max_rarity:      maxR,
        status,
        completed_at:    isComplete ? new Date().toISOString() : null,
      };

      const { data, error } = await supabase
        .from('hunter_challenges')
        .insert(row)
        .select()
        .single();

      if (error) throw error;
      return { challenge: data as HunterChallenge, wasAlreadyTracked: false };
    },

    onSuccess: (_data, variables) => {
      qc.invalidateQueries({ queryKey: [HUNTER_CHALLENGES_KEY, variables.userId] });
    },
  });
}

// ── useAddAdventurerChallenge ─────────────────────────────────

export function useAddAdventurerChallenge() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async (payload: AddAdventurerChallengePayload) => {
      const { data: existing } = await supabase
        .from('hunter_challenges')
        .select('id, status, created_at')
        .eq('user_id', payload.userId)
        .eq('adventurer_id', payload.adventurerId)
        .maybeSingle();

      if (existing && (existing.status === 'crafting' || existing.status === 'upgrading')) {
        return { challenge: existing as unknown as HunterChallenge, wasAlreadyTracked: true };
      }

      const curInsight = Math.max(0, Math.min(ADVENTURER_MAX_INSIGHT, payload.currentInsight ?? 0));
      const target = Math.max(1, Math.min(ADVENTURER_MAX_INSIGHT, payload.targetInsight ?? 1));
      const isComplete = curInsight >= target;
      const status: ChallengeStatus = isComplete ? 'completed' : curInsight > 0 ? 'upgrading' : 'crafting';

      const row = {
        user_id:         payload.userId,
        challenge_type:  'adventurer' as const,
        game:            payload.game || 'mho',
        adventurer_id:   payload.adventurerId,
        set_name:        payload.adventurerName,
        piece_image:     payload.pieceImage,
        set_icon:        payload.pieceImage,
        monster_name:    payload.adventurerName,
        craft_rarity:    1,
        current_rarity:  curInsight,
        max_rarity:      target,
        status,
        completed_at:    isComplete ? new Date().toISOString() : null,
        notes:           payload.notes || null,
      };

      // One row per user + adventurer (unique index), so a finished or abandoned goal is reused
      const query = existing
        ? supabase.from('hunter_challenges').update(row).eq('id', existing.id)
        : supabase.from('hunter_challenges').insert(row);

      const { data, error } = await query.select().single();

      if (error) throw error;
      return { challenge: data as HunterChallenge, wasAlreadyTracked: false };
    },

    onSuccess: (_data, variables) => {
      qc.invalidateQueries({ queryKey: [HUNTER_CHALLENGES_KEY, variables.userId] });
    },
  });
}

// ── useAddBuddyChallenge ──────────────────────────────────────

export function useAddBuddyChallenge() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async (payload: AddBuddyChallengePayload) => {
      // Check if an existing challenge exists for this buddy
      const { data: existing } = await supabase
        .from('hunter_challenges')
        .select('id, status, created_at')
        .eq('user_id', payload.userId)
        .eq('buddy_id', payload.buddyId)
        .maybeSingle();

      if (existing && (existing.status === 'crafting' || existing.status === 'upgrading')) {
        return { challenge: existing as unknown as HunterChallenge, wasAlreadyTracked: true };
      }

      // Convert buddy tier level (-1 = unowned, 0 = Tier 0, 1 = Tier 1, 2 = Tier 2) to challenge current_rarity (0..3)
      const curTierLevel = payload.currentTierLevel ?? -1;
      const curRarity = curTierLevel >= 0 ? Math.min(3, curTierLevel + 1) : 0;
      // targetTierLevel: 1 = recruit (Tier 0+), 2 = Tier 1, 3 = Tier 2 (Max)
      const target = Math.max(1, Math.min(3, payload.targetTierLevel ?? 1));
      const isComplete = curRarity >= target;
      const status: ChallengeStatus = isComplete ? 'completed' : curRarity > 0 ? 'upgrading' : 'crafting';

      const row = {
        user_id:         payload.userId,
        challenge_type:  'buddy' as const,
        game:            payload.game || 'mho',
        buddy_id:        payload.buddyId,
        set_name:        payload.buddyName,
        piece_image:     payload.pieceImage,
        set_icon:        payload.pieceImage,
        monster_name:    payload.buddyName,
        craft_rarity:    1,
        current_rarity:  curRarity,
        max_rarity:      target,
        status,
        completed_at:    isComplete ? new Date().toISOString() : null,
        notes:           payload.notes || null,
      };

      const query = existing
        ? supabase.from('hunter_challenges').update(row).eq('id', existing.id)
        : supabase.from('hunter_challenges').insert(row);

      const { data, error } = await query.select().single();

      if (error) throw error;
      return { challenge: data as HunterChallenge, wasAlreadyTracked: false };
    },

    onSuccess: (_data, variables) => {
      qc.invalidateQueries({ queryKey: [HUNTER_CHALLENGES_KEY, variables.userId] });
    },
  });
}

// ── useAddMonsterChallenge ────────────────────────────────────

export function useAddMonsterChallenge() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async (payload: AddMonsterChallengePayload) => {
      let query = supabase
        .from('hunter_challenges')
        .select('id, status, created_at, notes')
        .eq('user_id', payload.userId)
        .eq('challenge_type', 'monster')
        .eq('monster_id', payload.monsterId);

      if (payload.notes) {
        query = query.eq('notes', payload.notes);
      }

      const { data: existingList } = await query;
      const existing = existingList?.[0];

      if (existing && (existing.status === 'crafting' || existing.status === 'upgrading')) {
        return { challenge: existing as unknown as HunterChallenge, wasAlreadyTracked: true };
      }

      const isComplete = Boolean(payload.completed);
      const row = {
        user_id:         payload.userId,
        challenge_type:  'monster' as const,
        game:            payload.game || 'mho',
        monster_id:      payload.monsterId,
        set_name:        payload.monsterName,
        piece_image:     payload.pieceImage,
        set_icon:        payload.setIcon || payload.pieceImage,
        monster_name:    payload.monsterName,
        craft_rarity:    1,
        current_rarity:  isComplete ? 1 : 0,
        max_rarity:      1,
        status:          (isComplete ? 'completed' : 'crafting') as ChallengeStatus,
        completed_at:    isComplete ? new Date().toISOString() : null,
        notes:           payload.notes || null,
      };

      const res = existing
        ? await supabase.from('hunter_challenges').update(row).eq('id', existing.id).select().single()
        : await supabase.from('hunter_challenges').insert(row).select().single();

      if (res.error) throw res.error;
      return { challenge: res.data as HunterChallenge, wasAlreadyTracked: false };
    },

    onSuccess: (_data, variables) => {
      qc.invalidateQueries({ queryKey: [HUNTER_CHALLENGES_KEY, variables.userId] });
    },
  });
}

/** Highest rarity / level a challenge can reach: adventurer insight goal, 1-3 for buddy tier goals, 1 for monsters, 4 for visages. */
export function challengeMaxRarity(c: HunterChallenge): number {
  if (c.challenge_type === 'adventurer' || c.adventurer_id) {
    return Math.min(ADVENTURER_MAX_INSIGHT, Math.max(1, c.max_rarity || 1));
  }
  if (c.challenge_type === 'buddy' || c.buddy_id) {
    return Math.min(3, Math.max(1, c.max_rarity || 1));
  }
  if (c.challenge_type === 'monster') return 1;
  if (c.challenge_type === 'visage_set' || c.visage_id) return 4;
  return c.max_rarity || 16;
}

// ── useIncrementChallenge ─────────────────────────────────────
// Increments rarity and automatically syncs collection details for Visages, Adventurers & Buddies.

export function useIncrementChallenge() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async (challenge: HunterChallenge) => {
      const isVisage = challenge.challenge_type === 'visage_set' || Boolean(challenge.visage_id);
      const isAdventurer = challenge.challenge_type === 'adventurer' || Boolean(challenge.adventurer_id);
      const isBuddy = challenge.challenge_type === 'buddy' || Boolean(challenge.buddy_id);

      const cur = challenge.current_rarity ?? 0;
      const maxR = challengeMaxRarity(challenge);
      const craft = challenge.craft_rarity || 1;
      const newRarity = cur === 0 ? craft : Math.min(maxR, cur + 1);
      const isComplete = newRarity >= maxR;
      const newStatus: ChallengeStatus = isComplete ? 'completed' : 'upgrading';

      const updates: Record<string, unknown> = {
        current_rarity: newRarity,
        status:         newStatus,
      };
      if (isComplete) updates.completed_at = new Date().toISOString();

      const { data, error } = await supabase
        .from('hunter_challenges')
        .update(updates)
        .eq('id', challenge.id)
        .select()
        .single();

      if (error) throw error;

      // When stepping a visage challenge, automatically sync user_visage_collection
      if (isVisage && challenge.visage_id) {
        const rarityKey = VISAGE_RARITIES_BY_INDEX[newRarity];
        if (rarityKey) {
          await supabase.from('user_visage_collection').upsert(
            {
              user_id:    challenge.user_id,
              visage_id:  challenge.visage_id,
              ink_type:   (challenge.ink_type || 'flames').toLowerCase(),
              rarity:     rarityKey,
              quantity:   1,
              updated_at: new Date().toISOString(),
            },
            { onConflict: 'user_id,visage_id,ink_type' },
          );
        }
      }

      // When stepping an adventurer challenge, automatically sync user_adventurer_collection
      if (isAdventurer && challenge.adventurer_id) {
        await supabase.from('user_adventurer_collection').upsert(
          {
            user_id:       challenge.user_id,
            adventurer_id: challenge.adventurer_id,
            insight_level: newRarity,
            updated_at:    new Date().toISOString(),
          },
          { onConflict: 'user_id,adventurer_id' },
        );
      }

      // When stepping a buddy challenge, automatically sync user_buddy_collection
      if (isBuddy && challenge.buddy_id) {
        const newTier = Math.max(0, Math.min(2, newRarity - 1));
        await supabase.from('user_buddy_collection').upsert(
          {
            user_id:    challenge.user_id,
            buddy_id:   challenge.buddy_id,
            tier_level: newTier,
            quantity:   1,
            updated_at: new Date().toISOString(),
          },
          { onConflict: 'user_id,buddy_id' },
        );
      }

      return data as HunterChallenge;
    },

    onMutate: async (challenge) => {
      await qc.cancelQueries({ queryKey: [HUNTER_CHALLENGES_KEY] });
      const cur = challenge.current_rarity ?? 0;
      const maxR = challengeMaxRarity(challenge);
      const craft = challenge.craft_rarity || 1;
      const newRarity = cur === 0 ? craft : Math.min(maxR, cur + 1);
      const isComplete = newRarity >= maxR;

      qc.setQueriesData(
        { queryKey: [HUNTER_CHALLENGES_KEY], exact: false },
        (old: unknown) => {
          if (!Array.isArray(old)) return old;
          return (old as HunterChallenge[]).map((c) =>
            c.id === challenge.id
              ? {
                  ...c,
                  current_rarity: newRarity,
                  status:         isComplete ? 'completed' : 'upgrading',
                  completed_at:   isComplete ? new Date().toISOString() : c.completed_at,
                }
              : c,
          );
        },
      );
    },

    onSettled: () => {
      qc.invalidateQueries({ queryKey: [HUNTER_CHALLENGES_KEY] });
      qc.invalidateQueries({ queryKey: ['user-visage-collection'] });
      qc.invalidateQueries({ queryKey: ['user-adventurer-collection'] });
      qc.invalidateQueries({ queryKey: ['user-buddy-collection'] });
    },
  });
}

// ── useUpdateChallengeStatus ──────────────────────────────────

export function useUpdateChallengeStatus() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async ({
      challengeId,
      status,
      currentRarity,
      craftRarity,
      maxRarity,
      completedAt,
    }: UpdateChallengeStatusPayload) => {
      const updates: Record<string, unknown> = { status };
      if (currentRarity !== undefined) updates.current_rarity = currentRarity;
      if (craftRarity !== undefined)   updates.craft_rarity   = craftRarity;
      if (maxRarity !== undefined)     updates.max_rarity     = maxRarity;
      if (completedAt !== undefined)   updates.completed_at   = completedAt;

      const { data, error } = await supabase
        .from('hunter_challenges')
        .update(updates)
        .eq('id', challengeId)
        .select()
        .single();

      if (error) throw error;
      return data as HunterChallenge;
    },

    onMutate: async ({ challengeId, status, currentRarity, craftRarity, maxRarity, completedAt }) => {
      await qc.cancelQueries({ queryKey: [HUNTER_CHALLENGES_KEY] });

      qc.setQueriesData(
        { queryKey: [HUNTER_CHALLENGES_KEY], exact: false },
        (old: unknown) => {
          if (!Array.isArray(old)) return old;
          return (old as HunterChallenge[]).map((c) =>
            c.id === challengeId
              ? {
                  ...c,
                  status,
                  current_rarity: currentRarity !== undefined ? currentRarity : c.current_rarity,
                  craft_rarity:   craftRarity   !== undefined ? craftRarity   : c.craft_rarity,
                  max_rarity:     maxRarity     !== undefined ? maxRarity     : c.max_rarity,
                  completed_at:   completedAt   !== undefined ? completedAt   : c.completed_at,
                }
              : c,
          );
        },
      );
    },

    onSettled: () => {
      qc.invalidateQueries({ queryKey: [HUNTER_CHALLENGES_KEY] });
    },
  });
}

// ── useUpdateChallengeMaterial ────────────────────────────────
// Updates the missing_material and missing_material_activity fields

export function useUpdateChallengeMaterial() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async (payload: { id: string; material: string | null; activity: string | null }) => {
      const { data, error } = await supabase
        .from('hunter_challenges')
        .update({
          missing_material: payload.material,
          missing_material_activity: payload.activity,
        })
        .eq('id', payload.id)
        .select()
        .single();

      if (error) throw error;
      return data as HunterChallenge;
    },

    onMutate: async (payload) => {
      await qc.cancelQueries({ queryKey: [HUNTER_CHALLENGES_KEY] });
      qc.setQueriesData(
        { queryKey: [HUNTER_CHALLENGES_KEY], exact: false },
        (old: unknown) => {
          if (!Array.isArray(old)) return old;
          return (old as HunterChallenge[]).map((c) =>
            c.id === payload.id
              ? {
                  ...c,
                  missing_material: payload.material,
                  missing_material_activity: payload.activity,
                }
              : c,
          );
        },
      );
    },

    onSettled: () => {
      qc.invalidateQueries({ queryKey: [HUNTER_CHALLENGES_KEY] });
    },
  });
}

// ── useDeleteChallenge ────────────────────────────────────────

export function useDeleteChallenge() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async (challengeId: string) => {
      const { error } = await supabase
        .from('hunter_challenges')
        .delete()
        .eq('id', challengeId);

      if (error) throw error;
    },

    onMutate: async (challengeId) => {
      await qc.cancelQueries({ queryKey: [HUNTER_CHALLENGES_KEY] });
      qc.setQueriesData(
        { queryKey: [HUNTER_CHALLENGES_KEY], exact: false },
        (old: unknown) => {
          if (!Array.isArray(old)) return old;
          return (old as HunterChallenge[]).filter((c) => c.id !== challengeId);
        },
      );
    },

    onSettled: () => {
      qc.invalidateQueries({ queryKey: [HUNTER_CHALLENGES_KEY] });
    },
  });
}

// ── Derived helpers ───────────────────────────────────────────

/** True if this armour piece is currently active in hunter's challenges */
export function isArmourPieceTracked(
  challenges: HunterChallenge[],
  armourPieceId: string,
): boolean {
  return challenges.some(
    (c) =>
      c.armour_piece_id === armourPieceId &&
      c.status !== 'abandoned',
  );
}

/** Get the challenge for an armour piece, if one exists */
export function getArmourPieceChallenge(
  challenges: HunterChallenge[],
  armourPieceId: string,
): HunterChallenge | undefined {
  return challenges.find((c) => c.armour_piece_id === armourPieceId && c.status !== 'abandoned');
}

/** True if this weapon is currently active in hunter's challenges */
export function isWeaponTracked(
  challenges: HunterChallenge[],
  weaponId: string,
): boolean {
  return challenges.some(
    (c) =>
      c.weapon_id === weaponId &&
      c.status !== 'abandoned',
  );
}

/** Get the challenge for a weapon, if one exists */
export function getWeaponChallenge(
  challenges: HunterChallenge[],
  weaponId: string,
): HunterChallenge | undefined {
  return challenges.find(
    (c) =>
      c.weapon_id === weaponId &&
      c.status !== 'abandoned',
  );
}

/** True if this visage card is currently active in hunter's challenges */
export function isVisageTracked(
  challenges: HunterChallenge[],
  visageId: string,
  inkType?: string,
): boolean {
  const normInk = (inkType || '').toLowerCase();
  return challenges.some(
    (c) =>
      c.visage_id === visageId &&
      (!normInk || (c.ink_type || '').toLowerCase() === normInk) &&
      c.status !== 'abandoned',
  );
}

/** Get the challenge for a visage card, if one exists */
export function getVisageChallenge(
  challenges: HunterChallenge[],
  visageId: string,
  inkType?: string,
): HunterChallenge | undefined {
  const normInk = (inkType || '').toLowerCase();
  return challenges.find(
    (c) =>
      c.visage_id === visageId &&
      (!normInk || (c.ink_type || '').toLowerCase() === normInk) &&
      c.status !== 'abandoned',
  );
}

/** True if this adventurer is currently active in hunter's challenges */
export function isAdventurerTracked(
  challenges: HunterChallenge[],
  adventurerId: string,
): boolean {
  return challenges.some(
    (c) =>
      (c.adventurer_id === adventurerId || (c.challenge_type === 'adventurer' && c.set_name === adventurerId)) &&
      c.status !== 'abandoned',
  );
}

/** Get the challenge for an adventurer, if one exists */
export function getAdventurerChallenge(
  challenges: HunterChallenge[],
  adventurerId: string,
): HunterChallenge | undefined {
  return challenges.find(
    (c) =>
      (c.adventurer_id === adventurerId || (c.challenge_type === 'adventurer' && c.set_name === adventurerId)) &&
      c.status !== 'abandoned',
  );
}

/** True if this buddy is currently active in hunter's challenges */
export function isBuddyTracked(
  challenges: HunterChallenge[],
  buddyId: string,
): boolean {
  return challenges.some(
    (c) =>
      (c.buddy_id === buddyId || (c.challenge_type === 'buddy' && c.set_name === buddyId)) &&
      c.status !== 'abandoned',
  );
}

/** Get the challenge for a buddy, if one exists */
export function getBuddyChallenge(
  challenges: HunterChallenge[],
  buddyId: string,
): HunterChallenge | undefined {
  return challenges.find(
    (c) =>
      (c.buddy_id === buddyId || (c.challenge_type === 'buddy' && c.set_name === buddyId)) &&
      c.status !== 'abandoned',
  );
}

export interface MonsterLookup {
  id: string;
  name: string;
  icon?: string | null;
}

export interface WeaponLookup {
  id: string;
  monster_id?: string | null;
  name?: string;
  image?: string | null;
  series?: string | null;
}

/** Resolves the canonical monster ID for any challenge, resolving weapons and unlinked materials where needed */
export function getChallengeMonsterId(
  challenge: HunterChallenge,
  weaponsMap?: Map<string, WeaponLookup>,
  monstersMap?: Map<string, MonsterLookup>,
): string | null {
  // If explicitly stored on the challenge
  if (challenge.monster_id) return challenge.monster_id;

  // If it's a weapon challenge, look up weapon's monster_id
  if (challenge.weapon_id && weaponsMap) {
    const w = weaponsMap.get(challenge.weapon_id);
    if (w?.monster_id) return w.monster_id;
  }

  // If monster name is known and monstersMap is provided, look up by name
  if (challenge.monster_name && monstersMap) {
    const lower = challenge.monster_name.trim().toLowerCase();
    for (const m of monstersMap.values()) {
      if (m.name.toLowerCase() === lower) return m.id;
    }
  }

  // Check weapon forge materials if available
  if (challenge.weapon_id && monstersMap) {
    const mats = WEAPON_FORGE_MATERIALS[challenge.weapon_id] || [];
    for (const m of monstersMap.values()) {
      if (mats.some((mat) => mat.item.toLowerCase().includes(m.name.toLowerCase()))) {
        return m.id;
      }
    }
  }

  // Check weapon series or name for known monster
  if (monstersMap && challenge.weapon_id && weaponsMap) {
    const w = weaponsMap.get(challenge.weapon_id);
    const candidate = `${w?.series || ''} ${w?.name || ''}`.toLowerCase();
    for (const m of monstersMap.values()) {
      if (candidate.includes(m.name.toLowerCase())) {
        return m.id;
      }
    }
  }

  return null;
}

/** Resolves the display monster name for a challenge */
export function getChallengeMonsterName(
  challenge: HunterChallenge,
  weaponsMap?: Map<string, WeaponLookup>,
  monstersMap?: Map<string, MonsterLookup>,
): string | null {
  const monsterId = getChallengeMonsterId(challenge, weaponsMap, monstersMap);
  if (monsterId && monstersMap) {
    const m = monstersMap.get(monsterId);
    if (m?.name) return m.name;
  }
  if (challenge.monster_name) return challenge.monster_name;
  if (monsterId && monsterId !== '__general__') return monsterId.replace(/_/g, ' ');
  return null;
}

/** Resolves the monster icon for a challenge, guaranteeing weapon images are never used as monster icons */
export function getChallengeMonsterIcon(
  challenge: HunterChallenge,
  weaponsMap?: Map<string, WeaponLookup>,
  monstersMap?: Map<string, MonsterLookup>,
): string | null {
  const monsterId = getChallengeMonsterId(challenge, weaponsMap, monstersMap);
  if (monsterId && monstersMap) {
    const m = monstersMap.get(monsterId);
    if (m?.icon) return m.icon;
  }
  // If set_icon is present on the challenge and is NOT a weapon image
  if (challenge.set_icon && !challenge.set_icon.includes('/weapons/')) {
    return challenge.set_icon;
  }
  return null;
}

/** Group active challenges by monster for the Hunting Targets panel, grouping weapons under their respective monster */
export function groupChallengesByMonster(
  challenges: HunterChallenge[],
  weaponsMap?: Map<string, WeaponLookup>,
  monstersMap?: Map<string, MonsterLookup>,
): Map<string, { monsterName: string; setIcon: string | null; challenges: HunterChallenge[] }> {
  const map = new Map<string, { monsterName: string; setIcon: string | null; challenges: HunterChallenge[] }>();

  for (const c of challenges) {
    if (c.status === 'completed' || c.status === 'abandoned') continue;

    const monsterId = getChallengeMonsterId(c, weaponsMap, monstersMap);
    const monsterName = getChallengeMonsterName(c, weaponsMap, monstersMap);
    const monsterIcon = getChallengeMonsterIcon(c, weaponsMap, monstersMap);

    const key = monsterId ?? (monsterName || '__general__');
    const displayName = monsterName ?? (monsterId ? monsterId.replace(/_/g, ' ') : 'General / Material');

    if (!map.has(key)) {
      map.set(key, {
        monsterName: displayName,
        setIcon:     monsterIcon,
        challenges:  [],
      });
    } else {
      const group = map.get(key)!;
      // Upgrade placeholder/missing icon with the monster icon
      if (!group.setIcon && monsterIcon) {
        group.setIcon = monsterIcon;
      }
    }
    map.get(key)!.challenges.push(c);
  }

  return map;
}

/** Human-readable status label */
export function challengeStatusLabel(c: HunterChallenge): string {
  const isVisage = c.challenge_type === 'visage_set' || Boolean(c.visage_id);
  if (isVisage) {
    if (c.status === 'crafting') return 'Find (Fine)';
    if (c.status === 'upgrading') {
      const nextR = c.current_rarity === 1 ? 'Rare' : c.current_rarity === 2 ? 'Epic' : 'Superior';
      return `Find → ${nextR}`;
    }
    if (c.status === 'completed') return 'Found (Superior)';
    return 'Abandoned';
  }

  const isAdventurer = c.challenge_type === 'adventurer' || Boolean(c.adventurer_id);
  if (isAdventurer) {
    const target = challengeMaxRarity(c);
    if (target <= 1) return c.status === 'completed' ? 'Recruited' : 'Recruit';
    if (c.status === 'completed') return `Insight ${adventurerInsightLabel(target)}`;
    if (c.status === 'upgrading') {
      return `Insight ${adventurerInsightLabel(c.current_rarity)} → ${adventurerInsightLabel(target)}`;
    }
    return `Recruit → ${adventurerInsightLabel(target)}`;
  }

  const isBuddy = c.challenge_type === 'buddy' || Boolean(c.buddy_id);
  if (isBuddy) {
    const target = challengeMaxRarity(c);
    const targetLabel = target === 1 ? 'Recruit' : target === 2 ? 'Tier 1' : 'Tier Max (2)';
    if (target <= 1) return c.status === 'completed' ? 'Recruited' : 'Recruit';
    if (c.status === 'completed') return targetLabel;
    if (c.status === 'upgrading') {
      const curTier = Math.max(0, (c.current_rarity || 1) - 1);
      return `Tier ${curTier} → ${targetLabel}`;
    }
    return `Recruit → ${targetLabel}`;
  }

  if (c.challenge_type === 'monster') {
    if (c.status === 'completed') return 'Done';
    return 'Study';
  }

  if (c.status === 'crafting')  return 'Craft';
  if (c.status === 'upgrading') return `Upgrade R${c.current_rarity} → R${c.max_rarity}`;
  if (c.status === 'completed') return 'Completed';
  return 'Abandoned';
}

/** Next rarity to unlock after current_rarity, given a list of unlock tiers */
export function nextUnlockRarity(
  currentRarity: number,
  distinctUnlockRarities: number[],
  maxRarity: number = 16,
): number | null {
  const sorted = [...new Set([...distinctUnlockRarities, maxRarity])].sort((a, b) => a - b);
  const next   = sorted.find((r) => r > currentRarity);
  return next ?? null;
}
