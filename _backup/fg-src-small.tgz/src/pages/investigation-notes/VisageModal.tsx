// ─────────────────────────────────────────────────────────────
// VisageModal — Detailed card inspect view for MHO Visage Cards
// ─────────────────────────────────────────────────────────────
import { useNavigate } from 'react-router-dom';
import { X, Sparkles, Trash2, Target, CheckCircle2, Plus } from 'lucide-react';
import type { DBVisage, VisageRarity } from '../../data/schemas/visage';
import {
  INK_CONFIG,
  DEFAULT_VISAGE_RARITY,
  VISAGE_MAX_LEVEL_LABELS,
  getInkConfig,
  VISAGE_RARITY_CONFIG,
  VISAGE_RARITY_OPTIONS,
} from '../../data/schemas/visage';
import type { CardCollectionEntry } from '../../hooks/useVisageSets';
import type { HunterChallenge } from '../../hooks/useHunterChallenges';
import { InkIconComponent } from './VisageCard';
import { cn } from '../../lib/utils';
import VisageIcon from '../../components/visage/VisageIcon';

interface VisageModalProps {
  card: DBVisage | null;
  currentInk?: string;
  open: boolean;
  onClose: () => void;
  collectionEntry?: CardCollectionEntry | null;
  challenge?: HunterChallenge;
  onSetRarity?: (rarity: VisageRarity, quantity?: number) => void;
  onSetQuantity?: (quantity: number) => void;
  onRemoveFromCollection?: () => void;
  onAddChallenge?: (card: DBVisage, inkType: string, currentRarity?: VisageRarity | null) => void;
}

export default function VisageModal({
  card,
  currentInk,
  open,
  onClose,
  collectionEntry,
  challenge,
  onSetRarity,
  onSetQuantity,
  onRemoveFromCollection,
  onAddChallenge,
}: VisageModalProps) {
  const navigate = useNavigate();

  if (!open || !card) return null;

  const primaryInk = currentInk || card.ink_types[0] || 'flames';
  const inkCfg = getInkConfig(primaryInk);

  const isOwned = Boolean(collectionEntry);
  const currentRarity = collectionEntry?.rarity;
  const currentQty = collectionEntry?.quantity ?? 1;
  const rarityCfg = currentRarity ? VISAGE_RARITY_CONFIG[currentRarity] : null;

  const isTracked = Boolean(challenge && challenge.status !== 'abandoned');
  const isChallengeDone = challenge?.status === 'completed';
  const isMaxed = currentRarity === 'superior';

  const nextRarityName = !currentRarity
    ? 'Fine (Green)'
    : currentRarity === 'fine'
    ? 'Rare (Blue)'
    : currentRarity === 'rare'
    ? 'Epic (Purple)'
    : 'Superior (Gold)';

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity animate-in fade-in duration-150"
        onClick={onClose}
      />

      {/* Modal Dialog */}
      <div
        role="dialog"
        aria-modal="true"
        className={cn(
          'relative z-10 w-full max-w-lg overflow-hidden rounded-2xl border border-mh-gold-500/40 bg-mh-slate-900 shadow-2xl animate-in zoom-in-95 duration-150',
          'text-mh-slate-100',
        )}
        style={{
          boxShadow: '0 20px 50px rgba(0, 0, 0, 0.8), 0 0 30px rgba(234, 179, 8, 0.15)',
        }}
      >
        {/* Top Header with in-game gold accent */}
        <div className="flex items-center justify-between border-b border-mh-slate-750 bg-gradient-to-r from-mh-slate-950 via-mh-slate-900 to-mh-slate-950 px-6 py-4">
          <div className="flex items-center gap-2.5">
            <div className={cn('flex h-8 w-8 items-center justify-center rounded-lg border', inkCfg.bg, inkCfg.border, inkCfg.text)}>
              <InkIconComponent iconName={inkCfg.iconName} size={18} />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-display text-base font-bold text-mh-slate-100">
                  Visage: {card.name}
                </h3>
                {card.name_ja && (
                  <span className="text-xs text-mh-slate-400">({card.name_ja})</span>
                )}
                {(card.status === 'not_in_game' || card.is_spoiler) && (
                  <span
                    className="rounded-lg px-2 py-0.5 text-[10px] font-bold border border-amber-500/50 bg-amber-500/20 text-amber-300"
                    title={card.status_reason ?? 'Coming — Not in game yet'}
                  >
                    Coming{card.status_reason ? ` — ${card.status_reason}` : ''}
                  </span>
                )}
              </div>
              <p className="font-mono text-[11px] text-mh-slate-500">ID: {card.id}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-mh-slate-400 hover:bg-mh-slate-800 hover:text-white transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {/* Card Presentation Row */}
          <div className="flex flex-col sm:flex-row items-center gap-5">
            {/* Card Graphic View */}
            <div
              className={cn(
                'relative flex flex-col items-center justify-between w-32 h-44 rounded-xl p-0 border-2 shrink-0 shadow-lg overflow-hidden',
                isOwned && rarityCfg
                  ? cn(rarityCfg.borderClass, 'text-mh-slate-900')
                  : 'border-[#8e7646]',
              )}
              style={{
                boxShadow: isOwned && rarityCfg
                  ? `0 10px 25px rgba(0,0,0,0.5), 0 0 15px ${rarityCfg.glowColor}`
                  : undefined,
              }}
            >
              <div
                className={cn(
                  'relative flex flex-1 w-full items-center justify-center overflow-hidden',
                  isOwned && rarityCfg
                    ? rarityCfg.bgGradient
                    : 'bg-gradient-to-b from-[#f3e5be] via-[#e2cf9f] to-[#cfba84]',
                )}
              >
                <VisageIcon visage={card} rarity={currentRarity ?? DEFAULT_VISAGE_RARITY} />
              </div>

              <div className="w-full flex items-center justify-between p-2 bg-black/85 border-t border-black/30">
                <div className="flex items-center gap-1 rounded bg-black/75 px-1.5 py-0.5 border border-amber-500/40 text-white">
                  <InkIconComponent iconName={inkCfg.iconName} size={12} className={inkCfg.text} />
                  <span className="font-display text-xs font-bold text-amber-300">
                    {card.points} Pts
                  </span>
                </div>
                <span className="rounded bg-black/60 px-1.5 py-0.5 text-[9px] font-bold uppercase text-amber-200">
                  {card.monster_type}
                </span>
              </div>
            </div>

            {/* Quick Stats Column */}
            <div className="flex-1 space-y-3 w-full">
              <div className="grid grid-cols-2 gap-2">
                <div className="rounded-lg bg-mh-slate-800/80 p-2.5 border border-mh-slate-750">
                  <span className="block text-[10px] uppercase font-bold text-mh-slate-400">
                    Points Cost
                  </span>
                  <span className="font-display text-lg font-bold text-mh-gold-400">
                    {card.points} Points
                  </span>
                </div>

                <div className="rounded-lg bg-mh-slate-800/80 p-2.5 border border-mh-slate-750">
                  <span className="block text-[10px] uppercase font-bold text-mh-slate-400">
                    Max Level
                  </span>
                  <div className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs font-bold text-mh-slate-300">
                    {card.max_levels.length === 0 && <span>—</span>}
                    {card.max_levels.map((level, i) => (
                      <span key={i} title={VISAGE_MAX_LEVEL_LABELS[i]} className="inline-flex items-center gap-0.5">
                        <span className="text-[9px] uppercase text-mh-slate-500">
                          {VISAGE_MAX_LEVEL_LABELS[i]}
                        </span>
                        <span className="text-mh-gold-400">{level}</span>
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Possible Ink Rolls Pool */}
              <div className="rounded-lg bg-mh-slate-800/80 p-2.5 border border-mh-slate-750">
                <span className="block text-[10px] uppercase font-bold text-mh-slate-400 mb-1.5">
                  Ink Type
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {card.ink_types.length === 0 && (
                    <span className="text-[11px] text-mh-slate-500">None</span>
                  )}
                  {card.ink_types.map((ink) => {
                    const cfg = INK_CONFIG[ink] || getInkConfig(ink);
                    return (
                      <span
                        key={ink}
                        className={cn(
                          'inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[11px] font-bold border shadow-sm',
                          cfg.bg,
                          cfg.text,
                          cfg.border,
                        )}
                      >
                        <InkIconComponent iconName={cfg.iconName} size={11} />
                        {cfg.name}
                      </span>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Collection Status & Rarity Picker Box */}
          <div className="rounded-xl bg-mh-slate-950/90 p-4 border border-mh-slate-800 space-y-3.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-mh-slate-300">
                Hunter Collection Status
              </span>
              {isOwned && rarityCfg && (
                <span className={cn('rounded-md px-2 py-0.5 text-[11px] font-bold border', rarityCfg.badgeClass)}>
                  {rarityCfg.name} ({currentQty >= 5 ? '5+' : `${currentQty}x`})
                </span>
              )}
            </div>

            {/* Rarity Options Button Group */}
            <div className="grid grid-cols-4 gap-2">
              {VISAGE_RARITY_OPTIONS.map((rarityKey) => {
                const cfg = VISAGE_RARITY_CONFIG[rarityKey];
                const isSelected = currentRarity === rarityKey;
                return (
                  <button
                    key={rarityKey}
                    type="button"
                    onClick={() => onSetRarity?.(rarityKey, isSelected ? currentQty : 1)}
                    className={cn(
                      'flex flex-col items-center justify-center rounded-lg p-2 border transition-all text-center',
                      isSelected
                        ? 'bg-mh-slate-800 border-mh-gold-400 ring-1 ring-mh-gold-400'
                        : 'bg-mh-slate-900 border-mh-slate-800 hover:border-mh-slate-600 hover:bg-mh-slate-850',
                    )}
                  >
                    <span className={cn('h-3.5 w-3.5 rounded-full shadow-sm mb-1', cfg.dotClass)} />
                    <span className="text-xs font-bold text-mh-slate-200">{cfg.name}</span>
                    <span className="text-[10px] text-mh-slate-500">({cfg.colorName})</span>
                  </button>
                );
              })}
            </div>

            {/* Challenge Tracking CTA */}
            <div className="pt-2 border-t border-mh-slate-800/80 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <img
                  src="/img/ui/Challenge%20Icon.png"
                  alt=""
                  draggable={false}
                  className="h-7 w-7 shrink-0 object-contain"
                />
                <div>
                  <p className="text-xs font-bold text-mh-slate-200">Personal Hunter's Challenge</p>
                  <p className="text-[10px] text-mh-slate-400">
                    {isMaxed
                      ? 'Already found maximum Superior card'
                      : isTracked
                      ? `Currently searching: Goal ${nextRarityName}`
                      : `Set goal to search for next card: ${nextRarityName}`}
                  </p>
                </div>
              </div>

              {isMaxed ? (
                <span className="inline-flex items-center gap-1 rounded-lg bg-emerald-500/15 border border-emerald-500/30 px-3 py-1.5 text-xs font-bold text-emerald-300">
                  <CheckCircle2 size={13} className="text-emerald-400" />
                  <span>Found (Superior)</span>
                </span>
              ) : isTracked && !isChallengeDone ? (
                <button
                  type="button"
                  onClick={() => navigate(`/challenges?challenge=${challenge?.id}`)}
                  title="Go to this search on the Challenges page"
                  className="inline-flex items-center gap-1 rounded-lg bg-blue-500/15 border border-blue-500/30 px-3 py-1.5 text-xs font-bold text-blue-300 hover:bg-blue-500/25 transition-colors shrink-0"
                >
                  <Target size={13} className="text-blue-400" />
                  <span>Searching ➔</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => onAddChallenge?.(card, primaryInk, currentRarity)}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-sky-600/50 bg-transparent text-sky-400 hover:bg-sky-900 hover:border-sky-500 hover:text-sky-200 px-3.5 py-1.5 text-xs font-bold transition-all shadow-md shrink-0"
                >
                  <Plus size={14} />
                  <span>+ Search Challenge</span>
                </button>
              )}
            </div>

            {/* Quantity Selector if Owned */}
            {isOwned && (
              <div className="flex items-center justify-between pt-2 border-t border-mh-slate-800/80">
                <span className="text-xs text-mh-slate-400 font-medium">
                  Count Owned (1 - 5+):
                </span>
                <div className="flex items-center gap-1.5">
                  {[1, 2, 3, 4, 5].map((q) => (
                    <button
                      key={q}
                      type="button"
                      onClick={() => onSetQuantity?.(q)}
                      className={cn(
                        'h-7 w-8 rounded-md text-xs font-bold transition-colors border',
                        currentQty === q
                          ? 'bg-mh-gold-500 text-slate-950 border-mh-gold-400 font-extrabold'
                          : 'bg-mh-slate-900 text-mh-slate-300 border-mh-slate-750 hover:bg-mh-slate-800',
                      )}
                    >
                      {q === 5 ? '5+' : q}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => onRemoveFromCollection?.()}
                    title="Remove from collection"
                    className="ml-2 p-1.5 rounded-md text-rose-400 hover:bg-rose-500/20 transition-colors"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Core Inherent Effect Box */}
          <div className="rounded-xl bg-gradient-to-b from-mh-slate-950 to-mh-slate-900 p-4 border border-mh-gold-500/30 space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs font-bold text-mh-gold-400">
              <Sparkles size={14} />
              <span>Core Inherent Effect</span>
            </div>
            <p className="text-sm text-mh-slate-200 leading-relaxed font-sans">
              {card.core_effect || 'Increases hunter capabilities and boosts set resonance in Aesoland hunts.'}
            </p>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-end border-t border-mh-slate-750 bg-mh-slate-950/80 px-6 py-3.5">
          <button
            onClick={onClose}
            className="rounded-lg bg-mh-slate-800 px-5 py-2 text-xs font-bold text-mh-slate-200 hover:bg-mh-slate-700 hover:text-white transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
