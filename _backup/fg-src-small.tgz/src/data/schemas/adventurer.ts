// ─────────────────────────────────────────────────────────────
// Adventurer (MHO Playable Characters) Schema & Configuration
// ─────────────────────────────────────────────────────────────

export type AdventurerRole = 'Assault' | 'Disrupter' | 'Disruptor' | 'Support';

export interface AdventurerRoleConfig {
  role: 'Assault' | 'Disrupter' | 'Support';
  label: string;
  icon: string;
  bg: string;
  text: string;
  border: string;
  dotColor: string;
  description: string;
}

export const ADVENTURER_ROLE_CONFIG: Record<'Assault' | 'Disrupter' | 'Support', AdventurerRoleConfig> = {
  Assault: {
    role: 'Assault',
    label: 'Assault',
    icon: '/images/roles/assault.png',
    bg: 'bg-red-500/15',
    text: 'text-red-400',
    border: 'border-red-500/30',
    dotColor: 'bg-red-500',
    description: 'High-damage combat specialist focused on relentless offensive combos and part breaks.',
  },
  Disrupter: {
    role: 'Disrupter',
    label: 'Disrupter',
    icon: '/images/roles/disrupter.png',
    bg: 'bg-purple-500/15',
    text: 'text-purple-400',
    border: 'border-purple-500/30',
    dotColor: 'bg-purple-400',
    description: 'Tactical specialist specializing in crowd control, status ailments, stuns, and monster interruptions.',
  },
  Support: {
    role: 'Support',
    label: 'Support',
    icon: '/images/roles/support.png',
    bg: 'bg-emerald-500/15',
    text: 'text-emerald-400',
    border: 'border-emerald-500/30',
    dotColor: 'bg-emerald-400',
    description: 'Team coordinator providing heals, stat buffs, utility, and survival enhancements.',
  },
};

/** Inline border colour for cards/panels; dimmed when `strong` is false. Undefined if no rarity is set. */
export function adventurerRarityBorder(
  rarity: AdventurerRarity | null | undefined,
  strong = true,
): { borderColor: string; boxShadow?: string } | undefined {
  if (!rarity) return undefined;
  const { color } = ADVENTURER_RARITY_CONFIG[rarity];
  return strong
    ? { borderColor: color, boxShadow: `0 0 14px color-mix(in srgb, ${color} 25%, transparent)` }
    : { borderColor: `color-mix(in srgb, ${color} 70%, transparent)` };
}

export const ADVENTURER_ROLES: ('Assault' | 'Disrupter' | 'Support')[] = ['Assault', 'Disrupter', 'Support'];

/** In-game recruit rarity, using the same keys as visage cards (superior = SSR, epic = SR, rare = R). */
export type AdventurerRarity = 'rare' | 'epic' | 'superior';

export const ADVENTURER_RARITIES: AdventurerRarity[] = ['superior', 'epic', 'rare'];

export const ADVENTURER_RARITY_CONFIG: Record<
  AdventurerRarity,
  { label: string; short: string; color: string; bg: string }
> = {
  superior: { label: 'SSR (Gold)',  short: 'SSR',  color: 'var(--rarity-superior)', bg: 'var(--bg-superior)' },
  epic:     { label: 'SR (Purple)', short: 'SR',   color: 'var(--rarity-epic)',     bg: 'var(--bg-epic)' },
  rare:     { label: 'Rare (Blue)', short: 'Rare', color: 'var(--rarity-rare)',     bg: 'var(--bg-rare)' },
};

/** Insight levels run 1-7; the top level is shown as "Max". */
export const ADVENTURER_MAX_INSIGHT = 7;
export const ADVENTURER_INSIGHT_LEVELS = [1, 2, 3, 4, 5, 6, 7] as const;

export function adventurerInsightLabel(level: number): string {
  return level >= ADVENTURER_MAX_INSIGHT ? 'Max' : `Lv ${level}`;
}

export function clampInsightLevel(level: unknown): number {
  const n = Math.round(Number(level));
  if (!Number.isFinite(n)) return 1;
  return Math.min(ADVENTURER_MAX_INSIGHT, Math.max(1, n));
}

export interface ElementOption {
  id: string;
  label: string;
  color: string;
  border: string;
  bg: string;
  text: string;
}

export const ELEMENT_OPTIONS: Record<string, ElementOption> = {
  fire: { id: 'fire', label: 'Fire', color: 'text-orange-400', border: 'border-orange-500/40', bg: 'bg-orange-500/15', text: 'text-orange-300' },
  water: { id: 'water', label: 'Water', color: 'text-blue-400', border: 'border-blue-500/40', bg: 'bg-blue-500/15', text: 'text-blue-300' },
  thunder: { id: 'thunder', label: 'Thunder', color: 'text-yellow-400', border: 'border-yellow-500/40', bg: 'bg-yellow-500/15', text: 'text-yellow-300' },
  ice: { id: 'ice', label: 'Ice', color: 'text-cyan-400', border: 'border-cyan-500/40', bg: 'bg-cyan-500/15', text: 'text-cyan-300' },
  dragon: { id: 'dragon', label: 'Dragon', color: 'text-red-400', border: 'border-red-500/40', bg: 'bg-red-500/15', text: 'text-red-300' },
  poison: { id: 'poison', label: 'Poison', color: 'text-purple-400', border: 'border-purple-500/40', bg: 'bg-purple-500/15', text: 'text-purple-300' },
  paralysis: { id: 'paralysis', label: 'Paralysis', color: 'text-amber-400', border: 'border-amber-500/40', bg: 'bg-amber-500/15', text: 'text-amber-300' },
  sleep: { id: 'sleep', label: 'Sleep', color: 'text-indigo-400', border: 'border-indigo-500/40', bg: 'bg-indigo-500/15', text: 'text-indigo-300' },
  blast: { id: 'blast', label: 'Blast', color: 'text-rose-400', border: 'border-rose-500/40', bg: 'bg-rose-500/15', text: 'text-rose-300' },
  raw: { id: 'raw', label: 'Raw / Physical', color: 'text-mh-slate-300', border: 'border-mh-slate-600', bg: 'bg-mh-slate-800', text: 'text-mh-slate-300' },
};

export type AdventurerStatus = 'in_game' | 'not_in_game';

export interface DBAdventurer {
  id: string;
  name: string;
  name_ja: string | null;
  /** Portrait shown on cards and in the modal header. */
  image: string | null;
  /** Large image used as the background of the information panel. Null until uploaded. */
  background_image?: string | null;
  is_default: boolean;
  weapon_type: string | null;
  allowed_weapon_types: string[];
  element_specialization: string | null;
  role: AdventurerRole;
  /** Null/undefined until an admin assigns one. */
  rarity?: AdventurerRarity | null;
  description: string | null;
  notes: string | null;
  /** Epithet shown under the name, e.g. "Sword Inferno". */
  title?: string | null;
  gender?: 'male' | 'female' | null;
  /** Name of the buddy the adventurer starts with. */
  default_buddy?: string | null;
  traits?: AdventurerTrait[];
  playstyle?: string | null;
  height?: string | null;
  status: AdventurerStatus;
  /** Why the adventurer is not in the game (only set when status is 'not_in_game') */
  status_reason?: string | null;
  /** Visible in the Field Guide */
  is_active: boolean;
  /** Only shown to users who turned on "Show spoilers" */
  is_spoiler: boolean;
  /** Debug or test item */
  is_debug?: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export interface AdventurerTrait {
  name: string;
  description: string;
}

export interface AdventurerSkill {
  id: string;
  adventurer_id: string;
  sort_order: number;
  name: string;
  skill_type: string | null;
  description: string | null;
}

export type AdventurerUpsert = Omit<DBAdventurer, 'created_at' | 'updated_at'>;
