// ─────────────────────────────────────────────────────────────
// Visage (MHO Cards) Schema & Ink Types Definitions
// ─────────────────────────────────────────────────────────────

export type InkType =
  | 'might'
  | 'flames'
  | 'fire'
  | 'water'
  | 'thunder'
  | 'combat'
  | 'guidance'
  | 'grace'
  | 'ice'
  | 'frost'
  | 'dragon'
  | 'poison'
  | 'paralysis'
  | 'sleep'
  | 'blast'
  | 'resonance'
  | 'protection'
  | 'kushala_daoras_tempest';

export type VisageMonsterType = 'small' | 'large';

export interface InkConfig {
  id: InkType;
  name: string;
  shortName: string;
  bg: string;
  text: string;
  border: string;
  dotColor: string;
  glowColor: string;
  /** A lucide icon name, or a `/images/...` path to an ink icon image. */
  iconName:
    | 'sword' | 'flame' | 'droplet' | 'zap' | 'swords' | 'link' | 'sparkles' | 'snowflake' | 'skull' | 'moon' | 'shield' | 'activity'
    | `/${string}`;
}

export const INK_CONFIG: Record<InkType, InkConfig> = {
  might: {
    id: 'might',
    name: 'Ink of Might',
    shortName: 'Might',
    bg: 'bg-red-500/15',
    text: 'text-red-400',
    border: 'border-red-500/30',
    dotColor: 'bg-red-500',
    glowColor: 'rgba(239, 68, 68, 0.4)',
    iconName: '/images/inks/AmuletSuitIcon_Might.png',
  },
  flames: {
    id: 'flames',
    name: 'Ink of Flames',
    shortName: 'Flames',
    bg: 'bg-amber-500/15',
    text: 'text-amber-400',
    border: 'border-amber-500/30',
    dotColor: 'bg-amber-500',
    glowColor: 'rgba(245, 158, 11, 0.4)',
    iconName: '/images/inks/AmuletSuitIcon_Blaze.png',
  },
  fire: {
    id: 'fire',
    name: 'Ink of Flames',
    shortName: 'Flames',
    bg: 'bg-amber-500/15',
    text: 'text-amber-400',
    border: 'border-amber-500/30',
    dotColor: 'bg-amber-500',
    glowColor: 'rgba(245, 158, 11, 0.4)',
    iconName: '/images/inks/AmuletSuitIcon_Blaze.png',
  },
  water: {
    id: 'water',
    name: 'Ink of Water',
    shortName: 'Water',
    bg: 'bg-sky-500/15',
    text: 'text-sky-400',
    border: 'border-sky-500/30',
    dotColor: 'bg-sky-400',
    glowColor: 'rgba(56, 189, 248, 0.4)',
    iconName: '/images/inks/AmuletSuitIcon_Tide.png',
  },
  thunder: {
    id: 'thunder',
    name: 'Ink of Thunder',
    shortName: 'Thunder',
    bg: 'bg-[#FFE600]/15',
    text: 'text-[#FFE600]',
    border: 'border-[#FFE600]/35',
    dotColor: 'bg-[#FFE600]',
    glowColor: 'rgba(255, 230, 0, 0.45)',
    iconName: '/images/inks/AmuletSuitIcon_Bolt.png',
  },
  combat: {
    id: 'combat',
    name: 'Ink of Combat',
    shortName: 'Combat',
    bg: 'bg-rose-600/15',
    text: 'text-rose-400',
    border: 'border-rose-600/30',
    dotColor: 'bg-rose-500',
    glowColor: 'rgba(225, 29, 72, 0.4)',
    iconName: '/images/inks/AmuletSuitIcon_Assault.png',
  },
  guidance: {
    id: 'guidance',
    name: 'Ink of Guidance',
    shortName: 'Guidance',
    bg: 'bg-emerald-500/15',
    text: 'text-emerald-400',
    border: 'border-emerald-500/30',
    dotColor: 'bg-emerald-400',
    glowColor: 'rgba(16, 185, 129, 0.4)',
    iconName: '/images/inks/AmuletSuitIcon_Bind.png',
  },
  grace: {
    id: 'grace',
    name: 'Ink of Grace',
    shortName: 'Grace',
    bg: 'bg-teal-500/15',
    text: 'text-teal-300',
    border: 'border-teal-500/30',
    dotColor: 'bg-teal-300',
    glowColor: 'rgba(45, 212, 191, 0.4)',
    iconName: '/images/inks/AmuletSuitIcon_Grace.png',
  },
  ice: {
    id: 'ice',
    name: 'Ink of Frost',
    shortName: 'Frost',
    bg: 'bg-cyan-500/15',
    text: 'text-cyan-400',
    border: 'border-cyan-500/30',
    dotColor: 'bg-cyan-400',
    glowColor: 'rgba(6, 182, 212, 0.4)',
    iconName: '/images/inks/AmuletSuitIcon_Frost.png',
  },
  frost: {
    id: 'frost',
    name: 'Ink of Frost',
    shortName: 'Frost',
    bg: 'bg-cyan-500/15',
    text: 'text-cyan-400',
    border: 'border-cyan-500/30',
    dotColor: 'bg-cyan-400',
    glowColor: 'rgba(6, 182, 212, 0.4)',
    iconName: '/images/inks/AmuletSuitIcon_Frost.png',
  },
  dragon: {
    id: 'dragon',
    name: 'Ink of Dragon',
    shortName: 'Dragon',
    bg: 'bg-purple-500/15',
    text: 'text-purple-400',
    border: 'border-purple-500/30',
    dotColor: 'bg-purple-400',
    glowColor: 'rgba(168, 85, 247, 0.4)',
    iconName: '/images/inks/AmuletSuitIcon_Drake.png',
  },
  poison: {
    id: 'poison',
    name: 'Ink of Poison',
    shortName: 'Poison',
    bg: 'bg-purple-900/25',
    text: 'text-fuchsia-400',
    border: 'border-purple-600/30',
    dotColor: 'bg-fuchsia-400',
    glowColor: 'rgba(192, 38, 211, 0.4)',
    iconName: 'skull',
  },
  paralysis: {
    id: 'paralysis',
    name: 'Ink of Paralysis',
    shortName: 'Paralysis',
    bg: 'bg-amber-400/15',
    text: 'text-amber-300',
    border: 'border-amber-400/30',
    dotColor: 'bg-amber-300',
    glowColor: 'rgba(251, 191, 36, 0.4)',
    iconName: 'zap',
  },
  sleep: {
    id: 'sleep',
    name: 'Ink of Sleep',
    shortName: 'Sleep',
    bg: 'bg-indigo-500/15',
    text: 'text-indigo-400',
    border: 'border-indigo-500/30',
    dotColor: 'bg-indigo-400',
    glowColor: 'rgba(99, 102, 241, 0.4)',
    iconName: 'moon',
  },
  blast: {
    id: 'blast',
    name: 'Ink of Blast',
    shortName: 'Blast',
    bg: 'bg-orange-600/15',
    text: 'text-orange-400',
    border: 'border-orange-600/30',
    dotColor: 'bg-orange-500',
    glowColor: 'rgba(234, 88, 12, 0.4)',
    iconName: 'flame',
  },
  resonance: {
    id: 'resonance',
    name: 'Ink of Resonance',
    shortName: 'Resonance',
    bg: 'bg-emerald-600/15',
    text: 'text-emerald-300',
    border: 'border-emerald-600/30',
    dotColor: 'bg-emerald-300',
    glowColor: 'rgba(5, 150, 105, 0.4)',
    iconName: '/images/inks/AmuletSuitIcon_Arts.png',
  },
  protection: {
    id: 'protection',
    name: 'Ink of Protection',
    shortName: 'Protection',
    bg: 'bg-[#8B5A2B]/20',
    text: 'text-[#C48A52]',
    border: 'border-[#8B5A2B]/45',
    dotColor: 'bg-[#8B5A2B]',
    glowColor: 'rgba(139, 90, 43, 0.45)',
    iconName: '/images/inks/AmuletSuitIcon_Guard.png',
  },
  kushala_daoras_tempest: {
    id: 'kushala_daoras_tempest',
    name: "Kushala Daora's Tempest",
    shortName: 'Tempest',
    bg: 'bg-slate-400/15',
    text: 'text-slate-300',
    border: 'border-slate-400/35',
    dotColor: 'bg-slate-400',
    glowColor: 'rgba(148, 163, 184, 0.4)',
    iconName: '/images/inks/AmuletSuitIcon_KushalaDaora.png',
  },
};

export const INK_OPTIONS: InkType[] = [
  'might',
  'flames',
  'water',
  'thunder',
  'combat',
  'guidance',
  'grace',
  'ice',
  'frost',
  'dragon',
  'poison',
  'paralysis',
  'sleep',
  'blast',
  'resonance',
  'protection',
  'kushala_daoras_tempest',
];

/** Sets that are not named "Ink of ..." but are still selectable on cards */
export const CUSTOM_SET_INKS: InkType[] = ['kushala_daoras_tempest'];

export function getInkConfig(ink: string | null | undefined, customName?: string): InkConfig {
  if (!ink) return INK_CONFIG.flames;
  const key = ink.toLowerCase().replace(/^ink_of_/, '') as InkType;
  if (key === 'fire') return INK_CONFIG.flames;
  if (INK_CONFIG[key]) return INK_CONFIG[key];

  // Dynamic fallback for any custom set / ink from database
  const formattedName = customName || key
    .split('_')
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');

  const displayName = formattedName.toLowerCase().startsWith('ink of ') || formattedName.toLowerCase().includes(' set') || formattedName.toLowerCase().includes(' power') || formattedName.toLowerCase().includes(' mastery')
    ? formattedName
    : `Ink of ${formattedName}`;

  return {
    id: key,
    name: displayName,
    shortName: formattedName.replace(/^Ink of /i, ''),
    bg: 'bg-mh-gold-500/15',
    text: 'text-mh-gold-400',
    border: 'border-mh-gold-500/30',
    dotColor: 'bg-mh-gold-400',
    glowColor: 'rgba(217, 119, 6, 0.4)',
    iconName: 'sparkles',
  };
}

export const ELEMENT_TO_INK_MAP: Record<string, string[]> = {
  fire: ['flames', 'fire'],
  ice: ['frost', 'ice'],
  raw: ['combat', 'raw'],
  water: ['water'],
  thunder: ['thunder'],
  dragon: ['dragon'],
  poison: ['poison'],
  paralysis: ['paralysis'],
  blast: ['blast'],
  sleep: ['sleep'],
};

/** Pick the best ink for a card given the current weapon element */
export function chooseBestInk(inkTypes?: string[] | null, weaponElement?: string | null): string {
  if (!inkTypes || inkTypes.length === 0) return '';
  if (inkTypes.length === 1) return inkTypes[0];

  if (weaponElement) {
    const el = weaponElement.toLowerCase().trim();
    const possibleInks = ELEMENT_TO_INK_MAP[el] || [el];
    for (const ink of possibleInks) {
      const match = inkTypes.find((it) => it.toLowerCase() === ink);
      if (match) {
        return match;
      }
    }
  }

  return inkTypes[0];
}

export type VisageStatus = 'in_game' | 'not_in_game';

export interface DBVisage {
  id: string;
  name: string;
  name_ja: string | null;
  monster_id: string | null;
  monster_type: VisageMonsterType;
  points: number;
  /** Max level per card rarity: [Fine, Rare, Epic, Superior, Superior+] */
  max_levels: number[];
  /** Ink types this card belongs to */
  ink_types: InkType[];
  /** Joined from monsters.name */
  monster_name?: string | null;
  /** Joined from monsters.icon; the card art is composed from this + a rarity background */
  monster_icon?: string | null;
  /** Joined from monsters.sketch */
  monster_sketch?: string | null;
  /** Inherent / Core Effect of this Visage card */
  core_effect: string | null;
  /** Mapping of card quality to base effect pool ID, e.g. { rare: 102, epic: 105, superior: 108 } */
  base_effect_pools?: Record<'rare' | 'epic' | 'superior', number> | null;
  status: VisageStatus;
  status_reason: string | null;
  is_spoiler: boolean;
  is_active: boolean;
  notes: string | null;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export interface DBVisageBaseEffect {
  entry_id: number;
  pool_id: number;
  quality: string;
  monsters: string[];
  effect: string;
  tier: number;
  effect_chance: string;
  tier_chance: string;
  overall_chance: string;
  values_by_level: string[];
  created_at?: string;
}

export interface DBVisageResketchSlot {
  id: number;
  quality: 'Rare' | 'Epic' | 'Superior';
  slot: number;
  unlock_level: number;
  item_name: string;
  item_count: number;
  zenny: number;
  created_at?: string;
}

export interface DBVisageResketchPoolEntry {
  entry_id: number;
  quality: 'Rare' | 'Epic' | 'Superior';
  effect: string;
  roll_quality: 'Rare' | 'Epic' | 'Superior';
  effect_chance: string;
  roll_quality_chance: string;
  overall_chance: string;
  values: string[];
  value_chances: string[];
  created_at?: string;
}

export type VisageUpsert = Omit<DBVisage, 'created_at' | 'updated_at' | 'monster_name' | 'monster_icon' | 'monster_sketch'>;

/** Supabase select that pulls the linked monster name, icon and sketch along with the visage row */
export const VISAGE_SELECT = '*, monster:monsters(name, icon, sketch)';

/** Flattens the joined `monster` relation into `monster_name`, `monster_icon` and `monster_sketch` and normalises array columns */
export function normalizeVisageRow(row: Record<string, unknown>): DBVisage {
  const { monster, ...rest } = row as Record<string, unknown> & {
    monster?: { name?: string | null; icon?: string | null; sketch?: string | null } | null;
  };
  return {
    ...rest,
    points: typeof rest.points === 'number' ? rest.points : 1,
    max_levels: Array.isArray(rest.max_levels) ? (rest.max_levels as number[]) : [],
    ink_types: (Array.isArray(rest.ink_types) ? rest.ink_types : []) as InkType[],
    base_effect_pools: (rest.base_effect_pools as Record<'rare' | 'epic' | 'superior', number>) || null,
    status: ((rest.status as string) || 'in_game') as VisageStatus,
    status_reason: (rest.status_reason as string) || null,
    is_spoiler: Boolean(rest.is_spoiler),
    is_active: Boolean(rest.is_active),
    monster_name: monster?.name ?? null,
    monster_icon: monster?.icon ?? null,
    monster_sketch: monster?.sketch ?? null,
  } as DBVisage;
}

/** Labels for the entries of DBVisage.max_levels */
export const VISAGE_MAX_LEVEL_LABELS = ['Fine', 'Rare', 'Epic', 'Superior', 'Superior+'] as const;

// ── 4 Card Rarity Types (Fine, Rare, Epic, Superior) ───────────

export type VisageRarity = 'fine' | 'rare' | 'epic' | 'superior';

export interface VisageRarityConfig {
  id: VisageRarity;
  name: string;
  colorName: string;
  bgGradient: string;
  borderClass: string;
  hoverBorderClass: string;
  glowColor: string;
  dotClass: string;
  textClass: string;
  badgeClass: string;
}

export const VISAGE_RARITY_CONFIG: Record<VisageRarity, VisageRarityConfig> = {
  fine: {
    id: 'fine',
    name: 'Fine',
    colorName: 'Green',
    bgGradient: 'bg-gradient-to-b from-[#e3f4dd] via-[#d0eac8] to-[#b8ddae]',
    borderClass: 'border-[#508d44]',
    hoverBorderClass: 'hover:border-emerald-400',
    glowColor: 'rgba(34, 197, 94, 0.45)',
    dotClass: 'bg-emerald-500 text-white ring-1 ring-emerald-400',
    textClass: 'text-emerald-400',
    badgeClass: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
  },
  rare: {
    id: 'rare',
    name: 'Rare',
    colorName: 'Blue',
    bgGradient: 'bg-gradient-to-b from-[#d9ebfb] via-[#c0dcf8] to-[#a2c8ee]',
    borderClass: 'border-[#3c74b1]',
    hoverBorderClass: 'hover:border-sky-400',
    glowColor: 'rgba(56, 189, 248, 0.45)',
    dotClass: 'bg-sky-500 text-white ring-1 ring-sky-400',
    textClass: 'text-sky-400',
    badgeClass: 'bg-sky-500/20 text-sky-300 border-sky-500/40',
  },
  epic: {
    id: 'epic',
    name: 'Epic',
    colorName: 'Purple',
    bgGradient: 'bg-gradient-to-b from-[#eeddfb] via-[#dcbaf2] to-[#c598e7]',
    borderClass: 'border-[#8244b0]',
    hoverBorderClass: 'hover:border-purple-400',
    glowColor: 'rgba(168, 85, 247, 0.5)',
    dotClass: 'bg-purple-600 text-white ring-1 ring-purple-400',
    textClass: 'text-purple-400',
    badgeClass: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
  },
  superior: {
    id: 'superior',
    name: 'Superior',
    colorName: 'Gold',
    bgGradient: 'bg-gradient-to-b from-[#f3e5be] via-[#e2cf9f] to-[#cfba84]',
    borderClass: 'border-[#8e7646]',
    hoverBorderClass: 'hover:border-amber-400',
    glowColor: 'rgba(234, 179, 8, 0.5)',
    dotClass: 'bg-amber-400 text-slate-950 ring-1 ring-amber-300 font-bold',
    textClass: 'text-amber-400',
    badgeClass: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
  },
};

export const VISAGE_RARITY_OPTIONS: VisageRarity[] = ['fine', 'rare', 'epic', 'superior'];

/** Rarity used for card art where the user's owned rarity is unknown */
export const DEFAULT_VISAGE_RARITY: VisageRarity = 'superior';

/** Card background image for each rarity; the monster icon is layered on top */
export const VISAGE_BACKGROUNDS: Record<VisageRarity, string> = {
  fine: '/images/visages/Role_Amulet_Icon_Quality_01.png',
  rare: '/images/visages/Role_Amulet_Icon_Quality_02.png',
  epic: '/images/visages/Role_Amulet_Icon_Quality_03.png',
  superior: '/images/visages/Role_Amulet_Icon_Quality_04.png',
};

export interface UserVisageCollectionItem {
  user_id: string;
  visage_id: string;
  ink_type: string; // The specific ink type version of this card
  rarity: VisageRarity;
  quantity: number; // 1 to 5 (where 5 is 5+)
  created_at?: string;
  updated_at?: string;
}
