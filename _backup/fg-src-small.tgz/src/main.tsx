import React from 'react'
import ReactDOM from 'react-dom/client'
import { RouterProvider } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { router } from './router.tsx'
import { initAuth } from './store/authStore.ts'
import { initBuildDraftPersistence } from './store/buildDraftCookie.ts'
import './index.css'

// Bootstrap Supabase session listener before the React tree renders.
// This loads any persisted session from localStorage and subscribes
// to auth state changes (sign in, sign out, token refresh) for the
// app's lifetime.
initAuth()

// Restore the hunter's unsaved Build Planner selections from their cookie.
initBuildDraftPersistence()

// Discourage casual image saving: block the context menu and dragging on images only.
const isImage = (e: Event) => (e.target as HTMLElement | null)?.tagName === 'IMG'
document.addEventListener('contextmenu', (e) => { if (isImage(e)) e.preventDefault() })
document.addEventListener('dragstart', (e) => { if (isImage(e)) e.preventDefault() })

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      retry: 2,
    },
  },
})

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} />
    </QueryClientProvider>
  </React.StrictMode>,
)
